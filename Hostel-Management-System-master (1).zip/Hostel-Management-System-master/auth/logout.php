<?php
session_start();
$_SESSION["loggedin"]=NULL;
header("location:../index.php")


?>