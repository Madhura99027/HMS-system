<?php
session_start();
$_SESSION["aloggedin"]=NULL;
header("location:../adminlogin.php")


?>